import {API_SERVER}  from './apis'

export const HOME = '/'
export const LOGIN = '/login'
export const TASK_MANAGE = '/taskmanage'



export const API_USER_REG   = API_SERVER + '/user/reg'
export const API_USER_LOGIN = API_SERVER + '/login'
export const API_UPLOAD_IMG = API_SERVER + '/upload'



export const HOST_IMG = API_SERVER + '/'
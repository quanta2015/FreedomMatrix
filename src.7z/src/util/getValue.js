import get from 'get-value'

export default get

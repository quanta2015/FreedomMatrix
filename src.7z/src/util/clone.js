export default function clone(e) {
  return JSON.parse(JSON.stringify(e))
}
